import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldAlert, MapPin, MessageSquare, MicOff, PhoneCall, ArrowLeft, Send, Wifi, WifiOff, AlertTriangle, Loader2, Navigation, Heart, Package, Tent, LifeBuoy } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { GoogleGenAI } from '@google/genai';

let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({ apiKey });
  }
} catch (e) {
  console.warn("Failed to initialize GoogleGenAI in VictimPortal", e);
}

export default function GuestApp() {
  const { logout, user } = useAuth();
  const [activeIncident, setActiveIncident] = useState<string | null>(null);
  const [silentMode, setSilentMode] = useState(false);
  const [isOffline, setIsOffline] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState([
    { id: 1, sender: 'system', text: 'Connecting to SRAS Crisis Relief Network...' }
  ]);
  const [draft, setDraft] = useState('');
  
  const chatRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const triggerSOS = (type: string) => {
    setActiveIncident(type);
    setMessages([{ id: Date.now(), sender: 'system', text: `AI Triage: Interpreting ${type} emergency. Mission priority escalated. Coordinators mapped to your GPS.` }]);
    
    // Initialize Gemini Chat session for this incident
    if (ai) {
      chatRef.current = ai.chats.create({
        model: "gemini-2.5-flash",
        config: {
          systemInstruction: `You are SRAS Aid Assistant, a crisis-response AI for humanitarian relief. 
A beneficiary at location ${user?.location || 'Unknown'} has reported a ${type} emergency. 
Your goal is to safely triage the situation, provide immediate safety protocols (e.g., if fire, move to open ground; if flood, get to height), and facilitate dispatch by asking 1-2 critical questions (number of people, any immediate danger). 
Assure them that NGO coordinators are tracking their GPS via SRAS. 
Keep responses extremely tactical, empathetic, and short (max 2 sentences).`,
        }
      });
    }

    // Auto-greet
    setTimeout(async () => {
      setIsTyping(true);
      try {
        if (!ai || !chatRef.current) {
          setMessages(prev => [...prev, { id: Date.now(), sender: 'staff', text: "SRAS Network Active. Aid is being dispatched. (AI Offline)" }]);
          setIsTyping(false);
          return;
        }
        
        const response = await chatRef.current.sendMessage({ message: `I have a ${type} emergency. I'm scared. What should I do first?` });
        setMessages(prev => [...prev, { id: Date.now(), sender: 'staff', text: response.text }]);
      } catch (e) {
        setMessages(prev => [...prev, { id: Date.now(), sender: 'staff', text: "Network congestion. Aid is on the way. Stay calm and follow local safety signs." }]);
      } finally {
        setIsTyping(false);
      }
    }, 1000);
  };

  const sendMessage = async () => {
    if (!draft.trim() || isTyping) return;
    
    const userMsg = draft.trim();
    setMessages(prev => [...prev, { id: Date.now(), sender: 'user', text: userMsg }]);
    setDraft('');
    
    if (isOffline) {
       setTimeout(() => {
         setMessages(prev => [...prev, { id: Date.now(), sender: 'staff', text: 'Message queued for local mesh delivery. Coordinators will receive this via radio link.' }]);
       }, 1500);
       return;
    }

    setIsTyping(true);
    try {
      if (!ai || !chatRef.current) {
        setMessages(prev => [...prev, { id: Date.now(), sender: 'staff', text: "Processing via SRAS local relay..." }]);
        setIsTyping(false);
        return;
      }
      
      const response = await chatRef.current.sendMessage({ message: userMsg });
      setMessages(prev => [...prev, { id: Date.now(), sender: 'staff', text: response.text }]);
    } catch (e) {
      setMessages(prev => [...prev, { id: Date.now(), sender: 'staff', text: "Transmission received. Coordinate relay in progress." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#050506] flex flex-col max-w-md mx-auto shadow-2xl relative overflow-hidden font-sans text-[#E2E8F0] border-x border-white/5">
      <header className="p-4 flex items-center justify-between border-b border-white/5 bg-[#0F0F12] relative z-20">
        <div className="flex items-center gap-3">
          {activeIncident && (
            <button onClick={() => setActiveIncident(null)} className="p-2 -ml-2 text-zinc-500 hover:text-white transition">
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div className="flex flex-col">
            <span className="font-bold text-white tracking-wide text-sm">SRAS AID</span>
            <span className="text-[8px] text-zinc-500 uppercase tracking-widest font-bold">Relief Portal</span>
          </div>
          
          <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded text-[8px] font-bold tracking-widest uppercase transition-colors ${
              isOffline ? 'bg-amber-950/20 text-amber-500 border border-amber-500/20' : 'bg-blue-950/20 text-blue-500 border border-blue-500/20'
            }`}>
            {isOffline ? <WifiOff className="w-3 h-3" /> : <Wifi className="w-3 h-3" />}
            {isOffline ? 'MESH' : 'LIVE'}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => setSilentMode(!silentMode)} className={`p-2 rounded transition-colors ${silentMode ? 'bg-red-950/20 text-red-500 border border-red-500/20' : 'text-zinc-500 hover:bg-zinc-800'}`}>
            <MicOff className="w-4 h-4" />
          </button>
          <button onClick={logout} className="text-[9px] font-bold uppercase tracking-widest text-zinc-500 hover:text-white transition-colors bg-zinc-900 px-2 py-1 rounded border border-white/5">Exit</button>
        </div>
      </header>

      {isOffline && (
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-1.5 text-[9px] uppercase tracking-widest font-bold text-amber-500 flex items-center justify-center gap-2 relative z-10">
          <AlertTriangle className="w-3 h-3" /> Mesh Fallback Active
        </div>
      )}

      <div className="flex-1 overflow-y-auto overflow-x-hidden relative bg-[#0A0A0B]">
        <AnimatePresence mode="wait">
          {!activeIncident ? (
            <motion.div
              key="main"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="p-6 flex flex-col items-center justify-center min-h-full pb-20"
            >
              <div className="w-full text-center mb-10">
                <h2 className="text-xl font-bold tracking-tight text-white mb-1">Hello, {user?.name || 'Beneficiary'}</h2>
                <div className="flex items-center justify-center gap-2 text-[9px] uppercase font-bold text-zinc-500 tracking-widest bg-zinc-900/50 py-1 rounded-full w-fit mx-auto px-4 border border-white/5">
                  <Navigation className="w-3 h-3 text-blue-500" /> {user?.location || 'Detecting GPS...'}
                </div>
              </div>

              <div className="relative mb-14">
                <div className="absolute inset-0 bg-red-600/15 rounded-full blur-3xl animate-[pulse_3s_ease-in-out_infinite]" />
                <button
                  onClick={() => triggerSOS('GENERAL')}
                  className="relative group w-44 h-44 rounded-full flex flex-col items-center justify-center text-white border-4 border-[#0F0F12] shadow-[0_0_50px_rgba(220,38,38,0.3)] overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-b from-red-500 to-red-700 transition-transform group-hover:scale-110" />
                  <ShieldAlert className="w-12 h-12 mb-2 relative z-10" />
                  <span className="text-lg font-black tracking-[0.2em] relative z-10">SOS</span>
                </button>
                <div className="text-center mt-6 text-[9px] text-zinc-500 font-bold tracking-[0.2em] uppercase">
                  Immediate Dispatch
                </div>
              </div>

              <div className="w-full">
                <p className="text-[10px] uppercase font-bold text-zinc-600 tracking-widest mb-4 pl-1 text-center">Specific Aid Request</p>
                <div className="grid grid-cols-2 gap-4 w-full">
                  <button onClick={() => triggerSOS('MEDICAL')} className="p-5 rounded-2xl border border-white/5 bg-zinc-900/40 hover:bg-zinc-800 transition-all flex flex-col items-center gap-3">
                    <div className="w-10 h-10 flex items-center justify-center bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-emerald-400 group-hover:scale-110 transition-transform"><Heart className="w-5 h-5" /></div>
                    <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider">Medical</span>
                  </button>
                  <button onClick={() => triggerSOS('FOOD')} className="p-5 rounded-2xl border border-white/5 bg-zinc-900/40 hover:bg-zinc-800 transition-all flex flex-col items-center gap-3">
                    <div className="w-10 h-10 flex items-center justify-center bg-amber-500/10 rounded-xl border border-amber-500/20 text-amber-400"><Package className="w-5 h-5" /></div>
                    <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider">Food / Water</span>
                  </button>
                  <button onClick={() => triggerSOS('SHELTER')} className="p-5 rounded-2xl border border-white/5 bg-zinc-900/40 hover:bg-zinc-800 transition-all flex flex-col items-center gap-3">
                    <div className="w-10 h-10 flex items-center justify-center bg-blue-500/10 rounded-xl border border-blue-500/20 text-blue-400"><Tent className="w-5 h-5" /></div>
                    <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider">Shelter</span>
                  </button>
                  <button onClick={() => triggerSOS('RESCUE')} className="p-5 rounded-2xl border border-white/5 bg-zinc-900/40 hover:bg-zinc-800 transition-all flex flex-col items-center gap-3">
                    <div className="w-10 h-10 flex items-center justify-center bg-orange-500/10 rounded-xl border border-orange-500/20 text-orange-400"><LifeBuoy className="w-5 h-5" /></div>
                    <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider">Rescue</span>
                  </button>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="chat"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
              className="flex flex-col h-full absolute inset-0 bg-[#0A0A0B]"
            >
              <div className="bg-red-950/20 p-4 border-b border-red-500/10 backdrop-blur-md sticky top-0 z-20">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 bg-red-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.6)] animate-pulse" />
                  <div>
                    <div className="text-red-400 font-bold tracking-widest uppercase text-[10px]">{activeIncident} RESPONSE ACTIVE</div>
                    <div className="text-[9px] text-zinc-500 mt-0.5 uppercase tracking-wider">AI Analysis in progress • Coordinates locked</div>
                  </div>
                </div>
              </div>

              <div className="flex-1 p-4 overflow-y-auto space-y-4 scrollbar-hide">
                {messages.map((msg) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={msg.id} 
                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] p-3 text-xs tracking-wide leading-relaxed shadow-lg ${
                      msg.sender === 'user' ? 'bg-[#2563EB] text-white rounded-2xl rounded-br-none border border-blue-400/20' : 
                      msg.sender === 'system' ? 'bg-[#0F0F12] border border-white/5 text-zinc-500 text-[9px] uppercase font-mono tracking-widest rounded-lg text-center w-full shadow-none' : 
                      'bg-[#18181B] text-zinc-200 rounded-2xl rounded-bl-none border border-white/10'
                    }`}>
                      {msg.text}
                    </div>
                  </motion.div>
                ))}
                
                {isTyping && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                    <div className="max-w-[80%] p-3 bg-[#18181B] text-zinc-400 rounded-2xl rounded-bl-none border border-white/5 flex items-center gap-2">
                       <Loader2 className="w-4 h-4 animate-spin text-blue-500" /> <span className="text-[10px] uppercase font-bold tracking-widest italic">SRAS AI Analyzing...</span>
                    </div>
                  </motion.div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              <div className="p-4 bg-[#0F0F12]/80 backdrop-blur-xl border-t border-white/5 relative z-10 shrink-0">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
                    placeholder={silentMode ? "Type update silently..." : "Send info to relief command..."}
                    className="flex-1 bg-[#18181B] border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-blue-500/50 transition-all placeholder:text-zinc-600 shadow-inner"
                  />
                  <button onClick={sendMessage} className="w-12 h-12 bg-white rounded-xl text-black hover:bg-zinc-200 transition-all flex items-center justify-center shrink-0 shadow-lg active:scale-95">
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

