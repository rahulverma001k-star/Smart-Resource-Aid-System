import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { MapPin, AlertTriangle, Users, User, MessageSquare, Radio, ShieldAlert, CheckCircle2, Database, DatabaseZap, ShieldCheck, Crown, Activity, Navigation, Calendar, Clock, Video, Crosshair, Bell, LocateFixed, FileText } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from 'recharts';
import SRASAlphaAssistant from '../components/SRASAlphaAssistant';

const mockIncidents = [
  { id: 'INC-001', type: 'MEDICAL', status: 'ACTIVE', location: 'Yamuna Flood Zone', time: '2 mins ago', severity: 'high', score: 9, x: 75, y: 35 },
  { id: 'INC-002', type: 'FOOD', status: 'INVESTIGATING', location: 'Dharavi Relief Camp', time: '45 mins ago', severity: 'medium', score: 6, x: 25, y: 85 },
  { id: 'INC-003', type: 'SHELTER', status: 'ACTIVE', location: 'Jaipur North Zone', time: '1 hr ago', severity: 'high', score: 7, x: 45, y: 55 },
  { id: 'INC-004', type: 'RESCUE', status: 'ACTIVE', location: 'Kedarnath Sector 4', time: 'Just now', severity: 'high', score: 10, x: 15, y: 25 },
];

const mockVolunteerPositions = [
  { id: 'VOL-A', name: 'Priya (Medical)', x: 30, y: 80, lat: 28.6315, lng: 77.2167 },
  { id: 'VOL-B', name: 'Amit (Driver)', x: 65, y: 40, lat: 19.0760, lng: 72.8777 },
  { id: 'VOL-C', name: 'Sunita (Logistics)', x: 45, y: 45, lat: 26.9124, lng: 75.7873 },
];

const mockIoTSensors = [
  { id: 'SENS-01', location: 'Yamuna Water Level', status: 'ONLINE', x: 20, y: 80 },
  { id: 'SENS-02', location: 'Camp Alpha Smoke Det.', status: 'ONLINE', x: 70, y: 30 },
  { id: 'SENS-03', location: 'Storage Temp Monitor', status: 'OFFLINE', x: 50, y: 60 },
  { id: 'SENS-04', location: 'West Perimeter IR', status: 'ONLINE', x: 10, y: 50 },
];

const mockSchedule = [
  { day: 'Monday', morning: 'Sunita (Logistics)', evening: 'Rahul (Rescue)' },
  { day: 'Tuesday', morning: 'Amit (Driver)', evening: 'Priya (Medical)' },
  { day: 'Wednesday', morning: 'Dr. Rajesh (Medical)', evening: 'Mohit (Rescue)' },
  { day: 'Thursday', morning: 'Sunita (Logistics)', evening: 'Amit (Driver)' },
  { day: 'Friday', morning: 'Mohit (Rescue)', evening: 'Rahul (Rescue)' },
  { day: 'Saturday', morning: 'Priya (Medical)', evening: 'On-Call Only' },
  { day: 'Sunday', morning: 'On-Call Only', evening: 'On-Call Only' },
];

const data = [
  { time: '08:00', load: 10 }, { time: '09:00', load: 15 }, { time: '10:00', load: 12 }, 
  { time: '11:00', load: 25 }, { time: '12:00', load: 30 }, { time: '13:00', load: 45 },
  { time: '14:00', load: 35 }, { time: '15:00', load: 60 }, { time: '16:00', load: 40 }
];

const data24h = [
  { hour: '00:00', cases: 2, avgTime: 12 }, { hour: '04:00', cases: 1, avgTime: 8 },
  { hour: '08:00', cases: 8, avgTime: 15 }, { hour: '12:00', cases: 15, avgTime: 22 },
  { hour: '16:00', cases: 12, avgTime: 18 }, { hour: '20:00', cases: 5, avgTime: 14 }
];

export default function StaffDashboard() {
  const { logout, user } = useAuth();
  const [incidents, setIncidents] = useState(mockIncidents);
  const [activeTab, setActiveTab] = useState('map');
  const [dbSync, setDbSync] = useState(0);
  const [systemLogs, setSystemLogs] = useState([]);
  
  // New States to make everything functional
  const [sensors, setSensors] = useState(mockIoTSensors);
  const [volunteerPositions, setVolunteerPositions] = useState(mockVolunteerPositions);
  const [commsInput, setCommsInput] = useState('');
  const [commsMessages, setCommsMessages] = useState([
    { id: 1, sender: 'FIELD COMMAND', text: 'Status check on Yamuna Sector. Are we clear?', isSelf: true },
    { id: 2, sender: 'VOL-PRIYA', text: 'Sector is clear. Moving to transit camp now.', isSelf: false }
  ]);
  const [toast, setToast] = useState<{message: string, type: string} | null>(null);

  const showToast = (message: string, type = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  useEffect(() => {
    // GPS Simulation for Live Locations
    const gpsInterval = setInterval(() => {
      setVolunteerPositions(prev => prev.map(vol => {
        const newX = Math.max(10, Math.min(90, vol.x + (Math.random() - 0.5) * 3));
        const newY = Math.max(10, Math.min(90, vol.y + (Math.random() - 0.5) * 3));
        return {
          ...vol,
          x: newX,
          y: newY,
          lat: 28.6139 + (newY * 0.00005),
          lng: 77.2090 + (newX * 0.00005)
        };
      }));
    }, 2000);
    return () => clearInterval(gpsInterval);
  }, []);

  useEffect(() => {
    // Load saved information
    const logs = localStorage.getItem('sras_ai_logs');
    if (logs) {
      setSystemLogs(JSON.parse(logs));
    }

    // Simulate real-time DB percentage increasing
    const interval = setInterval(() => {
      setDbSync(prev => {
        const next = prev + 1;
        return next > 100 ? 100 : next;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A0B] flex flex-col xl:flex-row font-sans text-[#E2E8F0] relative">
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-4 left-1/2 -translate-x-1/2 px-6 py-3 rounded-full flex items-center justify-center gap-3 z-50 text-white shadow-2xl backdrop-blur-md animate-in slide-in-from-top-4 ${
          toast.type === 'error' ? 'bg-red-600/90 border border-red-500' :
          toast.type === 'warning' ? 'bg-amber-600/90 border border-amber-500' :
          'bg-blue-600/90 border border-blue-500'
        }`}>
          <Bell className="w-4 h-4 animate-bounce" />
          <span className="text-xs font-bold uppercase tracking-widest">{toast.message}</span>
        </div>
      )}

      {/* Sidebar */}
      <aside className="w-full xl:w-72 bg-[#0F0F12] border-r border-white/5 flex flex-col">
        <div className="p-6 border-b border-white/5 flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
            <ShieldAlert className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase">S R A S</h1>
            <p className="text-[10px] text-zinc-500 tracking-widest uppercase">Mission Command</p>
          </div>
        </div>
        
        <nav className="p-4 flex-1 space-y-2 hidden xl:block overflow-y-auto">
          <button onClick={() => setActiveTab('map')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'map' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <MapPin className="w-4 h-4 relative">
              {activeTab !== 'map' && <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full" />}
            </MapPin> <span className="text-sm font-semibold tracking-wide">Relief Map</span>
          </button>
          
          <button onClick={() => setActiveTab('incidents')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'incidents' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <AlertTriangle className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">Crisis Feed</span>
          </button>
          <button onClick={() => setActiveTab('comms')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'comms' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <MessageSquare className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">Field Comms</span>
          </button>
          <button onClick={() => setActiveTab('intake')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'intake' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <FileText className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">Report Intake</span>
          </button>
          <button onClick={() => setActiveTab('analytics')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'analytics' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <Activity className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">Aid Analytics</span>
          </button>
          <button onClick={() => setActiveTab('cameras')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'cameras' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <Radio className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">IoT Sensors</span>
          </button>
          <button onClick={() => setActiveTab('schedule')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'schedule' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <Calendar className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">Mission Schedule</span>
          </button>
          <button onClick={() => setActiveTab('roster')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${activeTab === 'roster' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <Users className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">Team Roster</span>
          </button>
          
          <button onClick={() => setActiveTab('system_db')} className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition mt-4 ${activeTab === 'system_db' ? 'bg-zinc-800 text-white border border-white/5' : 'text-zinc-400 hover:bg-zinc-900/50 hover:text-zinc-200'}`}>
            <div className="flex items-center gap-3">
              <Database className="w-4 h-4" /> <span className="text-sm font-semibold tracking-wide">Master Logs</span>
            </div>
            <span className="text-[10px] font-mono text-blue-400 bg-blue-900/20 px-2 py-0.5 rounded">{dbSync}%</span>
          </button>
        </nav>

        <div className="p-4 border-t border-white/5 bg-zinc-900/80">
          <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl mb-4">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-3 h-3 text-blue-500" />
              <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">SRAS Verified</span>
            </div>
            <p className="text-[10px] text-zinc-400">Mission-critical AI monitoring active.</p>
          </div>

          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-zinc-800 border border-white/10 flex items-center justify-center text-xs text-white uppercase font-bold">
                {user?.name?.charAt(0) || 'E'}
              </div>
              <div className="text-xs">
                <div className="text-zinc-200 font-semibold">{user?.name || 'Staff Member'}</div>
                <div className="text-zinc-500">{user?.position || 'Duty Manager'}</div>
              </div>
            </div>
          </div>
          <button onClick={logout} className="w-full py-2 border border-white/10 bg-black hover:bg-zinc-900 text-zinc-400 hover:text-white rounded text-xs font-bold transition flex items-center justify-center gap-2">
            SIGN OUT
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-[#050506]">
        {/* Top bar */}
        <header className="h-16 border-b border-white/10 bg-[#0F0F12] flex items-center justify-between px-6 shrink-0 w-full z-10">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-wider text-zinc-400">
              <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" />
              Sync Status: {dbSync}%
            </span>
            <div className="hidden md:flex items-center gap-2 text-[11px] font-medium uppercase tracking-wider text-zinc-400 border border-white/5 bg-zinc-900/50 px-3 py-1 rounded">
              <ShieldCheck className="w-3 h-3 text-emerald-500" /> Firebase + GCP
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => {
                showToast("GLOBAL SOS INITIATED: Broadcasting mandatory evacuation protocols to all guest endpoints.", "error");
                setIncidents(prev => [{ id: `INC-${Math.floor(Math.random() * 10000)}`, type: 'GENERAL EVACUATION', status: 'ACTIVE', location: 'ALL AREAS', time: 'Just now', severity: 'high', x: 50, y: 50, responder: '' }, ...prev]);
              }}
              className="px-4 py-1.5 bg-red-600/20 border border-red-600/50 text-red-500 rounded text-xs font-bold hover:bg-red-600/30 transition">
              GLOBAL SOS
            </button>
            <button 
              onClick={() => setActiveTab('comms')}
              className="text-zinc-400 hover:text-white transition relative p-2">
              <MessageSquare className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#0F0F12]" />
            </button>
          </div>
        </header>

        <div className="flex-1 flex flex-col xl:flex-row min-h-0 overflow-y-auto">
          {/* Dashboard Area */}
          <div className="flex-1 p-4 lg:p-6 space-y-6 overflow-y-auto min-h-0">
            
            {activeTab === 'map' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 shrink-0">
                  <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-4 flex flex-col justify-between h-32 hover:border-white/10 transition">
                    <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold flex items-center gap-2">
                       <AlertTriangle className="w-3 h-3 text-red-500" /> Crisis Reports
                    </span>
                    <div className="flex items-end gap-3 mt-2">
                      <div className="text-3xl font-light text-white">{incidents.filter(i => i.status === 'ACTIVE').length}</div>
                      <div className="text-[10px] text-red-500 mb-1 font-bold bg-red-950/30 px-2 py-0.5 rounded border border-red-500/20">+1 Today</div>
                    </div>
                    <p className="text-[10px] text-zinc-400 mt-2">Next Step: Field Dispatch</p>
                  </div>
                  
                  <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-4 flex flex-col justify-between h-32 hover:border-white/10 transition">
                    <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold flex items-center gap-2">
                      <Users className="w-3 h-3 text-blue-500" /> Volunteers Deployed
                    </span>
                    <div className="flex items-end gap-3 mt-2">
                      <div className="text-3xl font-light text-white">24</div>
                      <div className="text-[10px] text-green-400 mb-1 font-bold bg-green-900/20 px-2 py-0.5 rounded border border-green-500/20">Operational</div>
                    </div>
                    <p className="text-[10px] text-zinc-400 mt-2">Zone Capacity: Stable</p>
                  </div>
                  
                  <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-4 flex flex-col justify-between h-32 hover:border-white/10 transition">
                    <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold flex items-center gap-2">
                      <DatabaseZap className="w-3 h-3 text-orange-500" /> SRAS Intel Sync
                    </span>
                    <div className="flex items-end gap-3 mt-2">
                      <div className="text-3xl font-light text-white">{dbSync}%</div>
                      <div className="text-[10px] text-orange-400 mb-1 font-bold bg-orange-950/20 px-2 py-0.5 rounded border border-orange-500/20">Sync: Live</div>
                    </div>
                    <p className="text-[10px] text-zinc-400 mt-2">Relational Cloud Mesh</p>
                  </div>
                </div>

                {/* Map Area */}
                <div 
                   className="h-[400px] rounded-2xl bg-[#0F0F12] relative overflow-hidden border border-white/10 shrink-0 shadow-lg cursor-crosshair group"
                   onDoubleClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const x = ((e.clientX - rect.left) / rect.width) * 100;
                      const y = ((e.clientY - rect.top) / rect.height) * 100;
                      setIncidents(prev => [...prev, { id: `MANUAL-${Math.floor(Math.random() * 1000)}`, type: 'USER TAGGED', status: 'ACTIVE', location: 'Custom Pin', time: 'Just now', severity: 'medium', x, y }]);
                      showToast(`Custom drop pin added to map coordinate via user input.`, "info");
                   }}
                >
                  <div className="absolute inset-0 mock-map-bg opacity-20 pointer-events-none" />
                  
                  {/* Danger Zone overlays */}
                  <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-red-500/10 rounded-full blur-xl animate-pulse pointer-events-none" />
                  <div className="absolute bottom-1/3 right-1/3 w-40 h-40 bg-blue-500/5 rounded-full blur-xl pointer-events-none" />
                  
                  <div className="absolute inset-0 flex items-center justify-center p-8 pointer-events-none">
                    <div className="w-[80%] h-[70%] border border-white/10 relative rounded-lg bg-zinc-900/40 p-4">
                      <div className="w-full h-full grid grid-cols-4 grid-rows-3 gap-2 opacity-30">
                         <div className="border border-white/10 rounded overflow-hidden relative"><div className="absolute inset-x-0 bottom-0 h-1/2 bg-blue-500/20" /></div>
                         <div className="border border-white/10 rounded relative flex items-center justify-center"><span className="text-[8px] font-mono opacity-50">LOBBY</span></div>
                         <div className="border border-white/10 rounded bg-red-900/30 relative flex items-center justify-center"><span className="text-[8px] font-mono text-red-500 opacity-50">LOCKDOWN</span></div>
                         <div className="border border-white/10 rounded" />
                         <div className="border border-white/10 rounded relative flex items-center justify-center"><span className="text-[8px] font-mono opacity-50">HALL A</span></div>
                         <div className="border border-white/10 rounded bg-blue-900/20 relative flex items-center justify-center"><span className="text-[8px] font-mono text-blue-500 opacity-50">MEDICAL</span></div>
                         <div className="border border-white/10 rounded" />
                         <div className="border border-white/10 rounded" />
                         <div className="border border-white/10 rounded" />
                         <div className="border border-white/10 rounded" />
                         <div className="border border-white/10 rounded" />
                         <div className="border border-white/10 rounded relative flex items-center justify-center"><span className="text-[8px] font-mono opacity-50">EXIT</span></div>
                      </div>
                      
                      {/* Top HUD */}
                      <div className="absolute -top-4 -left-4 flex flex-col gap-2 z-10 pointer-events-none">
                         <div className="px-3 py-1 bg-black/80 border border-white/10 rounded-full text-[10px] text-white flex items-center gap-2 shadow-xl backdrop-blur-sm">
                           <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" /> LIVE DISPATCH MAP
                         </div>
                         <div className="px-3 py-1 bg-black/80 border border-white/10 rounded-full text-[10px] text-zinc-400 flex items-center gap-2 shadow-xl backdrop-blur-sm pointer-events-auto">
                           Double Click to Pin
                         </div>
                      </div>

                      {/* Dynamic Incident Markers */}
                      {incidents.filter(i => i.status !== 'RESOLVED').map(inc => (
                        <div 
                          key={inc.id}
                          className="absolute flex flex-col items-center animate-pulse pointer-events-auto cursor-pointer group z-20"
                          style={{ top: `${inc.y}%`, left: `${inc.x}%`, transform: 'translate(-50%, -50%)' }}
                          onClick={() => {
                             const newStatus = inc.status === 'ACTIVE' ? 'INVESTIGATING' : 'RESOLVED';
                             setIncidents(prev => prev.map(i => i.id === inc.id ? { ...i, status: newStatus } : i));
                             showToast(`Mission Status: Crisis updated to ${newStatus}`, "warning");
                          }}
                        >
                          <div className={`p-2 rounded-full transition-transform group-hover:scale-110 flex items-center justify-center ${
                            inc.status === 'ACTIVE' ? 'bg-red-600 shadow-[0_0_15px_rgba(220,38,38,0.6)]' : 'bg-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.6)]'
                          }`}>
                            <AlertTriangle className="w-4 h-4 text-white" />
                          </div>
                          <div className={`h-6 w-px ${inc.status === 'ACTIVE' ? 'bg-red-500' : 'bg-amber-500'}`} />
                          <div className={`absolute -top-10 flex flex-col items-center opacity-0 group-hover:opacity-100 transition-opacity z-30`}>
                            <span className={`text-[10px] font-mono bg-black border px-2 py-0.5 rounded shadow-xl whitespace-nowrap mb-1 ${
                              inc.status === 'ACTIVE' ? 'text-red-400 border-red-500/30' : 'text-amber-400 border-amber-500/30'
                            }`}>
                              {inc.id} ({inc.location})
                            </span>
                            <span className="text-[8px] bg-white/10 px-1 py-0.5 text-zinc-300 rounded font-mono uppercase tracking-widest px-2 backdrop-blur-md border border-white/5 whitespace-nowrap">{inc.type} | Click to Command</span>
                          </div>
                        </div>
                      ))}
                      
                      {/* Dynamic Volunteer Positions with GPS Tracking */}
                      {volunteerPositions.map(vol => (
                        <div 
                          key={vol.id}
                          className="absolute flex items-center gap-2 pointer-events-auto cursor-pointer group z-20"
                          style={{ top: `${vol.y}%`, left: `${vol.x}%`, transform: 'translate(-50%, -50%)', transition: 'top 2s linear, left 2s linear' }}
                          onClick={() => showToast(`Pinging ${vol.name} via SRAS Secure Satellite...`, "info")}
                        >
                          <div className="w-3 h-3 bg-blue-400 rounded-full shadow-[0_0_10px_rgba(96,165,250,0.5)] transition-transform group-hover:scale-125" />
                          <div className="absolute left-4 bg-black/80 p-2 rounded border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-30 flex flex-col gap-1 shadow-xl">
                            <span className="text-[10px] font-bold text-blue-300 uppercase">{vol.name}</span>
                            <span className="text-[9px] font-mono text-zinc-400 flex items-center gap-1"><LocateFixed className="w-3 h-3" /> LAT: {vol.lat?.toFixed(5)}</span>
                            <span className="text-[9px] font-mono text-zinc-400 flex items-center gap-1"><LocateFixed className="w-3 h-3 opacity-0" /> LNG: {vol.lng?.toFixed(5)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Aid Analytics */}
                <div className="h-[280px] rounded-2xl bg-[#0F0F12] border border-white/10 p-6 shrink-0 shadow-lg">
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-[11px] uppercase tracking-widest font-bold text-zinc-500">Relief Dispatch Load</h3>
                    <span className="text-[10px] bg-blue-900/20 text-blue-400 px-2 py-1 rounded font-mono border border-blue-500/20">Sync: GOOGLE CLOUD</span>
                  </div>
                  <div className="h-[180px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={data} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorLoad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="time" stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                        <Tooltip contentStyle={{ backgroundColor: '#0F0F12', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} itemStyle={{ color: '#E2E8F0', fontSize: '12px' }} />
                        <Area type="monotone" dataKey="load" stroke="#3b82f6" fillOpacity={1} fill="url(#colorLoad)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </>
            )}

            {activeTab === 'incidents' && (
              <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-6 shadow-lg min-h-[600px]">
                <h2 className="text-sm font-bold text-white mb-6 uppercase tracking-wider">Crisis Response Feed</h2>
                <div className="space-y-4">
                  {incidents.map(inc => (
                    <div key={inc.id} className="p-4 bg-zinc-900/50 border border-white/10 rounded-lg flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 flex items-center justify-center rounded bg-gradient-to-br ${
                          inc.severity === 'high' ? 'from-red-600/20 to-red-600/40 border border-red-500/50 text-red-500' :
                          inc.severity === 'medium' ? 'from-blue-600/20 to-blue-600/40 border border-blue-500/50 text-blue-500' :
                          'from-amber-600/20 to-amber-600/40 border border-amber-500/50 text-amber-500'
                        }`}>
                          <AlertTriangle className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-white tracking-wide">{inc.type} - {inc.location}</h4>
                          <div className="text-[10px] uppercase tracking-widest text-zinc-500 mt-1">ID: {inc.id} • {inc.time}</div>
                          {inc.responder && (
                            <div className="text-[10px] mt-2 font-bold text-blue-400 bg-blue-900/20 w-max px-2 py-0.5 rounded border border-blue-500/20">
                              Assigned Volunteer: {inc.responder}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className={`px-3 py-1 rounded text-[10px] font-bold uppercase tracking-widest border ${
                          inc.status === 'ACTIVE' ? 'bg-red-500/10 text-red-500 border-red-500/30' :
                          inc.status === 'INVESTIGATING' ? 'bg-amber-500/10 text-amber-500 border-amber-500/30' :
                          'bg-emerald-500/10 text-emerald-500 border-emerald-500/30'
                        }`}>
                          {inc.status}
                        </span>
                        
                        {inc.status !== 'RESOLVED' && (
                          <button 
                            onClick={() => {
                              const newStatus = inc.status === 'ACTIVE' ? 'INVESTIGATING' : 'RESOLVED';
                              setIncidents(prev => prev.map(i => i.id === inc.id ? { ...i, status: newStatus } : i));
                            }}
                            className="px-4 py-2 bg-white text-black text-[10px] font-bold uppercase tracking-widest rounded hover:bg-zinc-200 transition">
                            Mark {inc.status === 'ACTIVE' ? 'Investigating' : 'Resolved'}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'comms' && (
              <div className="bg-[#0F0F12] border border-white/5 rounded-xl flex flex-col shadow-lg h-[600px]">
                <div className="p-4 border-b border-white/5">
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">Field Operations Comms</h2>
                </div>
                <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-4">
                  {commsMessages.map((msg, idx) => (
                    <div key={idx} className={`${msg.isSelf ? 'self-end bg-[#27272A] rounded-br-sm' : 'self-start bg-[#18181B] rounded-bl-sm'} max-w-[80%] text-white p-3 rounded-xl border border-white/5 text-sm`}>
                      {!msg.isSelf && <span className="text-[10px] text-blue-400 font-bold block mb-1">{msg.sender}</span>}
                      {msg.isSelf && <span className="text-[10px] text-zinc-500 font-bold block mb-1 text-right">{msg.sender}</span>}
                      <span className={!msg.isSelf ? "text-zinc-300" : ""}>{msg.text}</span>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t border-white/5">
                  <form 
                    className="flex gap-2"
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!commsInput.trim()) return;
                      setCommsMessages(prev => [...prev, { id: Date.now(), sender: 'FIELD COMMAND', text: commsInput.trim(), isSelf: true }]);
                      setCommsInput('');
                      setTimeout(() => {
                        setCommsMessages(prev => [...prev, { id: Date.now(), sender: 'VOL-AMIT', text: 'Received Field Command. Deploying to site.', isSelf: false }]);
                      }, 1500);
                    }}
                  >
                    <input 
                      type="text" 
                      value={commsInput}
                      onChange={(e) => setCommsInput(e.target.value)}
                      placeholder="Relay mission instructions to volunteers..." 
                      className="flex-1 bg-[#18181B] border border-white/5 rounded px-4 py-2 text-sm text-white focus:outline-none focus:border-white/20" 
                    />
                    <button type="submit" disabled={!commsInput.trim()} className="px-6 bg-blue-600 text-white rounded text-xs font-bold uppercase tracking-widest hover:bg-blue-700 disabled:opacity-50 transition">Relay</button>
                  </form>
                </div>
              </div>
            )}

            {activeTab === 'roster' && (
              <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-6 shadow-lg min-h-[600px]">
                <h2 className="text-sm font-bold text-white mb-6 uppercase tracking-wider flex justify-between items-center">
                  Active Roster
                  <span className="text-[10px] bg-green-500/10 text-green-500 px-2 py-1 rounded border border-green-500/20">24 ON DUTY</span>
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div key={i} className="p-4 bg-zinc-900/50 border border-white/5 rounded-lg flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-zinc-800 rounded-full border border-white/10 flex items-center justify-center">
                          <User className="w-5 h-5 text-zinc-500" />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-white">Volunteer {String.fromCharCode(64 + i)}</div>
                          <div className="text-[10px] text-zinc-500 uppercase tracking-widest">Relief Team</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500" />
                        <span className="text-[10px] text-zinc-400 uppercase tracking-widest">Active</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'system_db' && (
              <div className="bg-[#0F0F12] border border-white/5 rounded-xl flex flex-col shadow-lg min-h-[600px]">
                <div className="p-6 border-b border-white/5 flex justify-between items-center">
                  <div>
                    <h2 className="text-sm font-bold text-white uppercase tracking-wider">SRAS Master Intel Logs</h2>
                    <p className="text-[10px] text-zinc-400 mt-1 uppercase tracking-widest">Firebase + GCP Secure Storage</p>
                  </div>
                  <div className="flex gap-2">
                    <span className="text-[10px] bg-blue-500/10 text-blue-500 px-3 py-1 rounded border border-blue-500/20 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" /> CLOUD SYNC ACTIVE
                    </span>
                  </div>
                </div>
                <div className="p-6 flex-1 overflow-y-auto">
                  {systemLogs.length === 0 ? (
                    <div className="text-center text-zinc-500 py-12 flex flex-col items-center gap-4">
                      <Database className="w-12 h-12 opacity-20" />
                      <p className="text-xs uppercase tracking-widest">No mission logs captured by AI triage yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {systemLogs.map((log, i) => (
                        <div key={i} className="p-4 bg-zinc-900/50 border border-white/5 rounded-lg">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest flex items-center gap-2">
                              <CheckCircle2 className="w-3 h-3" /> Mission Protocol Log
                            </span>
                            <span className="text-[10px] text-zinc-500 font-mono flex items-center gap-2">
                              <Activity className="w-3 h-3" />
                              {new Date(log.date).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-sm text-zinc-300 leading-relaxed font-mono mt-1">
                            {log.note}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-6 shadow-lg">
                    <h3 className="text-[11px] uppercase tracking-widest font-bold text-zinc-500 mb-6">24H Case Volume</h3>
                    <div className="h-[200px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={data24h} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                          <XAxis dataKey="hour" stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                          <YAxis stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                          <Tooltip contentStyle={{ backgroundColor: '#0F0F12', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} itemStyle={{ color: '#E2E8F0', fontSize: '12px' }} />
                          <Bar dataKey="cases" fill="#ef4444" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-6 shadow-lg">
                    <h3 className="text-[11px] uppercase tracking-widest font-bold text-zinc-500 mb-6">Avg Resolution Time (Mins)</h3>
                    <div className="h-[200px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={data24h} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id="colorTime" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#eab308" stopOpacity={0.2}/>
                              <stop offset="95%" stopColor="#eab308" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                          <XAxis dataKey="hour" stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                          <YAxis stroke="#52525b" fontSize={10} tickLine={false} axisLine={false} />
                          <Tooltip contentStyle={{ backgroundColor: '#0F0F12', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }} itemStyle={{ color: '#E2E8F0', fontSize: '12px' }} />
                          <Area type="monotone" dataKey="avgTime" stroke="#eab308" fillOpacity={1} fill="url(#colorTime)" strokeWidth={2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'cameras' && (
              <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-6 shadow-lg min-h-[600px] flex flex-col gap-6">
                <div className="flex justify-between items-center border-b border-white/5 pb-4">
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider">IoT Sensor Mesh</h2>
                  <button 
                    onClick={() => {
                      const newSensorId = `SNR-${Math.floor(Math.random() * 100)}`;
                      setSensors(prev => [...prev, { id: newSensorId, location: 'New Field Unit', status: 'ONLINE', x: Math.random() * 80 + 10, y: Math.random() * 80 + 10 }]);
                      showToast(`Hardware Registry: Registered node ${newSensorId} successfully.`, "info");
                    }} 
                    className="px-4 py-2 bg-blue-600/20 border border-blue-500/50 text-blue-400 rounded text-[10px] font-bold tracking-widest uppercase hover:bg-blue-600/40 transition">
                    + Register Node
                  </button>
                </div>
                
                {/* Map Representation of Sensors */}
                <div className="h-[250px] shrink-0 rounded-2xl bg-[#0F0F12] border border-white/10 relative overflow-hidden bg-zinc-900/30">
                   <div className="absolute top-4 left-4 text-[10px] bg-black/80 px-2 py-1 rounded text-zinc-400 font-mono tracking-widest z-10 border border-white/10">
                     FIELD SENSOR RELAY OVERLAY
                   </div>
                   {sensors.map(sensor => (
                     <div key={sensor.id} className="absolute flex flex-col items-center z-10 cursor-pointer group" style={{ top: `${sensor.y}%`, left: `${sensor.x}%`, transform: 'translate(-50%, -50%)' }}>
                       <div className={`p-1.5 rounded-full ${sensor.status === 'ONLINE' ? 'bg-green-500/20 border border-green-500 text-green-400' : 'bg-red-500/20 border border-red-500 text-red-500'} group-hover:scale-125 transition-transform`}>
                         <Radio className="w-3 h-3" />
                       </div>
                       <span className="absolute -bottom-6 text-[9px] font-mono whitespace-nowrap bg-black px-1 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity z-20">
                         {sensor.id}
                       </span>
                     </div>
                   ))}
                </div>

                {/* List Representation */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {sensors.map((sensor) => (
                    <div key={sensor.id} className="p-4 bg-zinc-900/50 border border-white/5 rounded-lg flex items-center justify-between hover:bg-zinc-800/50 transition">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded border flex items-center justify-center ${sensor.status === 'ONLINE' ? 'bg-green-900/20 border-green-500/30' : 'bg-red-900/20 border-red-500/30'}`}>
                          <Radio className={`w-4 h-4 ${sensor.status === 'ONLINE' ? 'text-green-500' : 'text-red-500'}`} />
                        </div>
                        <div>
                          <div className="text-sm font-bold text-white">{sensor.location}</div>
                          <div className="text-[10px] text-zinc-500 uppercase tracking-widest font-mono">{sensor.id}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {sensor.status === 'ONLINE' ? (
                          <span className="text-[10px] bg-green-500/10 text-green-500 px-2 py-1 rounded border border-green-500/20 uppercase font-bold tracking-widest">Active</span>
                        ) : (
                          <span className="text-[10px] bg-red-500/10 text-red-500 px-2 py-1 rounded border border-red-500/20 uppercase font-bold tracking-widest animate-pulse">Offline</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'intake' && (
              <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-8 shadow-lg min-h-[600px]">
                <div className="max-w-2xl mx-auto">
                  <h2 className="text-xl font-bold text-white mb-2 uppercase tracking-wide">Relief Intake Protocol</h2>
                  <p className="text-[11px] text-zinc-400 mb-8 uppercase tracking-widest">Manual Data Entry for Satellite Dispatches</p>
                  
                  <form className="space-y-6" onSubmit={(e) => {
                    e.preventDefault();
                    showToast("SRAS Intelligence: Report submitted. AI Priority Scoring in progress...", "success");
                    setActiveTab('incidents');
                  }}>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Report Type</label>
                        <select className="w-full bg-[#18181B] border border-white/10 rounded px-4 py-2 text-white text-sm focus:border-blue-500 transition outline-none">
                          <option>Medical Emergency</option>
                          <option>Supply Shortage</option>
                          <option>Structural Damage</option>
                          <option>Security Incident</option>
                          <option>Missing Person</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Location Sector</label>
                        <input type="text" placeholder="Sector 7G / Block C" className="w-full bg-[#18181B] border border-white/10 rounded px-4 py-2 text-white text-sm focus:border-blue-500 transition outline-none" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Victim Name (Optional)</label>
                      <input type="text" placeholder="Full name if available" className="w-full bg-[#18181B] border border-white/10 rounded px-4 py-2 text-white text-sm focus:border-blue-500 transition outline-none" />
                    </div>

                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Incident Description</label>
                      <textarea rows={4} placeholder="Describe the situation in detail for AI assessment..." className="w-full bg-[#18181B] border border-white/10 rounded px-4 py-2 text-white text-sm focus:border-blue-500 transition outline-none resize-none" />
                    </div>

                    <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-lg flex items-start gap-4">
                      <div className="p-2 bg-blue-500/20 rounded">
                        <ShieldCheck className="w-5 h-5 text-blue-500" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-zinc-200">SRAS AI Dispatch Trigger</p>
                        <p className="text-[10px] text-zinc-500 leading-relaxed mt-1">This report will be processed by Gemini for urgency scoring and matched with nearest available relief resources automatically.</p>
                      </div>
                    </div>

                    <button type="submit" className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold uppercase tracking-widest rounded shadow-xl shadow-blue-600/10 transition-all active:scale-95">
                      Submit Relief Request
                    </button>
                  </form>
                </div>
              </div>
            )}

            {activeTab === 'schedule' && (
              <div className="bg-[#0F0F12] border border-white/5 rounded-xl p-6 shadow-lg min-h-[600px]">
                <h2 className="text-sm font-bold text-white mb-2 uppercase tracking-wider">Volunteer Duty Rotation</h2>
                <p className="text-[10px] text-zinc-400 mb-6 uppercase tracking-widest">7-Day NGO Field Support Schedule</p>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm text-zinc-300">
                    <thead className="text-[10px] uppercase bg-zinc-900/50 text-zinc-400 border-y border-white/5 tracking-widest h-12">
                      <tr>
                        <th className="px-6 py-3 font-semibold text-zinc-300">Operations Window</th>
                        <th className="px-6 py-3 font-semibold text-blue-400"><Clock className="w-3 h-3 inline mr-2" />Morning Relief (08:00 - 16:00)</th>
                        <th className="px-6 py-3 font-semibold text-amber-500"><Clock className="w-3 h-3 inline mr-2" />Night Support (16:00 - 00:00)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {mockSchedule.map((entry, index) => (
                        <tr key={index} className="hover:bg-zinc-900/30 transition-colors h-14">
                          <td className="px-6 py-4 font-bold text-white tracking-wide border-r border-white/5">{entry.day}</td>
                          <td className="px-6 py-4 font-medium border-r border-white/5 text-zinc-400">{entry.morning}</td>
                          <td className="px-6 py-4 font-medium text-zinc-400">{entry.evening}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* Incident Feed */}
          <aside className="w-full xl:w-80 bg-[#0F0F12] border-l border-white/5 flex flex-col shrink-0 min-h-[400px]">
            <div className="p-4 border-b border-white/5 bg-zinc-900/30 flex justify-between items-center">
              <h2 className="text-[11px] uppercase tracking-widest font-semibold text-zinc-500">Live Incident Feed</h2>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-2 p-3">
              {incidents.map(inc => (
                <div 
                  key={inc.id} 
                  onClick={() => {
                     // If clicking an active incident in the sidebar, open a prompt or cycle it
                     if (inc.status !== 'RESOLVED') {
                       const newStatus = inc.status === 'ACTIVE' ? 'INVESTIGATING' : 'RESOLVED';
                       if (window.confirm(`Update incident ${inc.id} to ${newStatus}?`)) {
                         setIncidents(prev => prev.map(i => i.id === inc.id ? { ...i, status: newStatus } : i));
                       }
                     }
                  }}
                  className={`p-3 border rounded-lg relative cursor-pointer hover:brightness-110 transition ${
                  inc.status === 'ACTIVE' ? 'bg-red-950/20 border-red-500/30' : 
                  inc.status === 'INVESTIGATING' ? 'bg-amber-950/20 border-amber-500/30' : 
                  'bg-zinc-900/50 border-white/5'
                }`}>
                  {inc.status === 'ACTIVE' && <div className="absolute right-2 top-2 w-2 h-2 bg-red-500 rounded-full animate-pulse" />}
                  
                  <p className={`text-[10px] font-bold mb-1 uppercase tracking-wider ${
                    inc.severity === 'high' ? 'text-red-400' : inc.severity === 'medium' ? 'text-blue-400' : 'text-amber-400'
                  }`}>
                    {inc.severity === 'high' ? 'CRITICAL' : inc.severity === 'medium' ? 'NOTICE' : 'WARNING'} • {inc.type}
                  </p>
                  
                  <h3 className="text-sm font-semibold text-white">{inc.location}</h3>
                  <p className="text-xs text-zinc-400 mt-1 font-mono">{inc.id}</p>
                  
                  {inc.responder && (
                    <div className="mt-2 text-[10px] font-bold text-blue-400 bg-blue-900/20 w-max px-2 py-0.5 rounded border border-blue-500/20">
                      Assigned: {inc.responder}
                    </div>
                  )}
                  
                  <div className="mt-3 flex items-center justify-between">
                     <span className="px-2 py-0.5 bg-zinc-800 rounded text-[10px] text-zinc-400 font-mono">{inc.time}</span>
                     <span className={`px-2 py-0.5 rounded text-[9px] uppercase font-bold tracking-wider ${
                        inc.status === 'ACTIVE' ? 'bg-red-900/40 text-red-200' : 
                        inc.status === 'INVESTIGATING' ? 'bg-amber-900/40 text-amber-200' : 
                        'bg-emerald-900/40 text-emerald-200'
                     }`}>
                       {inc.status}
                     </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Metrics */}
            <div className="p-4 bg-zinc-900/80 border-t border-white/10">
              <h4 className="text-[10px] uppercase font-bold text-zinc-400 mb-3">Platform Sync Status</h4>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-[10px] mb-1"><span className="text-zinc-500">IoT Data Sync</span><span className="text-green-400">98%</span></div>
                  <div className="w-full bg-zinc-800 h-1 rounded-full overflow-hidden"><div className="bg-green-500 h-full w-[98%]" /></div>
                </div>
                <div>
                  <div className="flex justify-between text-[10px] mb-1"><span className="text-zinc-500">Staff Presence</span><span className="text-blue-400">100%</span></div>
                  <div className="w-full bg-zinc-800 h-1 rounded-full overflow-hidden"><div className="bg-blue-500 h-full w-[100%]" /></div>
                </div>
              </div>
            </div>
          </aside>
        </div>
        
        {/* Footer */}
        <footer className="h-10 bg-black border-t border-white/5 px-6 flex items-center justify-between text-[10px] text-zinc-500 uppercase tracking-widest shrink-0">
          <div className="flex gap-6">
            <span>Session: <span className="text-zinc-300 font-mono">AE-7729-D</span></span>
            <span className="hidden sm:inline">Cloud: <span className="text-zinc-300 font-bold">GCP</span></span>
            <span className="hidden md:inline">MQTT: <span className="text-green-500">Connected</span></span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full border border-zinc-700" /> Offline: <span className="text-zinc-300">Standby</span></span>
            <span className="text-white font-bold bg-zinc-800 px-2 py-0.5 rounded">v1.0.4</span>
          </div>
        </footer>
      </main>

      {/* AI Assistant Widget */}
      <SRASAlphaAssistant incidents={incidents} setIncidents={setIncidents} user={user} />
    </div>
  );
}

