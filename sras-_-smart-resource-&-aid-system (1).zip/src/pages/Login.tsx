import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ShieldAlert, User, ShieldCheck, MapPin, Phone, Briefcase, ChevronRight, Lock, Heart, Users, Activity, Navigation, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Login() {
  const { login } = useAuth();
  const [activeTab, setActiveTab] = useState<'volunteer' | 'victim' | 'admin'>('volunteer');
  const [isDetecting, setIsDetecting] = useState(false);
  
  // Volunteer Form State
  const [volunteerData, setVolunteerData] = useState({
    name: '',
    phone: '',
    skill: 'Generalist',
    location: ''
  });

  // Victim/SOS Form State
  const [victimData, setVictimData] = useState({
    name: '',
    emergencyType: 'Medical',
    description: '',
    location: ''
  });

  const [adminData, setAdminData] = useState({
    email: '',
    password: ''
  });

  const handleVolunteerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login('volunteer', { ...volunteerData, id: `VOL-${Math.floor(Math.random() * 1000)}` });
  };

  const handleVictimSOS = (e: React.FormEvent) => {
    e.preventDefault();
    login('victim', { ...victimData, id: `SOS-${Math.floor(Math.random() * 1000)}` });
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login('admin', { email: adminData.email });
  };

  const detectLocation = () => {
    setIsDetecting(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        const loc = `${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`;
        if (activeTab === 'volunteer') setVolunteerData({ ...volunteerData, location: loc });
        if (activeTab === 'victim') setVictimData({ ...victimData, location: loc });
        setIsDetecting(false);
      }, () => setIsDetecting(false));
    } else {
      setIsDetecting(false);
    }
  };

  const skills = ['Medical', 'Driver', 'Logistics', 'Search & Rescue', 'Generalist'];
  const emergencies = ['Medical', 'Food', 'Shelter', 'Rescue', 'Fire', 'Flood'];

  return (
    <div className="min-h-screen bg-[#050506] font-sans text-[#E2E8F0] flex">
      
      {/* Left side - Branding */}
      <div className="hidden lg:flex flex-1 flex-col justify-between p-12 relative overflow-hidden bg-[#0A0A0B] border-r border-white/5">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-emerald-600/10 rounded-full blur-[120px] pointer-events-none" />
        </div>

        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)]">
            <ShieldAlert className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white uppercase">S R A S</h1>
            <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Smart Resource & Aid System</p>
          </div>
        </div>

        <div className="relative z-10 max-w-lg mb-20">
          <div className="flex gap-2 mb-6">
            <span className="px-2 py-1 bg-blue-500/10 border border-blue-500/20 rounded text-[9px] font-bold text-blue-400 uppercase tracking-widest">SDG 1</span>
            <span className="px-2 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded text-[9px] font-bold text-emerald-400 uppercase tracking-widest">SDG 11</span>
            <span className="px-2 py-1 bg-amber-500/10 border border-amber-500/20 rounded text-[9px] font-bold text-amber-400 uppercase tracking-widest">SDG 17</span>
          </div>

          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-bold tracking-tight text-white mb-6 uppercase leading-[1.1]"
          >
            AI-Powered<br/><span className="text-zinc-500">Crisis Relief</span>
          </motion.h2>
          <p className="text-zinc-400 text-lg mb-8 leading-relaxed font-light">
            Automating NGO response with Google Gemini AI. Real-time telemetry, smart resource dispatch, and volunteer matching for humanitarian aid missions.
          </p>
          
          <div className="flex gap-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded border border-white/10 flex items-center justify-center bg-zinc-900/50">
                <Heart className="w-4 h-4 text-red-500" />
              </div>
              <div>
                <div className="text-white font-bold text-sm">Humanitarian</div>
                <div className="text-[10px] text-zinc-500 uppercase tracking-widest">NGO Focused</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded border border-white/10 flex items-center justify-center bg-zinc-900/50">
                <Activity className="w-4 h-4 text-blue-500" />
              </div>
              <div>
                <div className="text-white font-bold text-sm">Gemini AI</div>
                <div className="text-[10px] text-zinc-500 uppercase tracking-widest">Smart Triage</div>
              </div>
            </div>
          </div>
        </div>

        <div className="relative z-10 flex flex-col gap-2">
            <div className="text-[10px] text-zinc-600 uppercase tracking-widest font-mono">
              Built with Google Gemini AI • Firebase • Google Maps Platform
            </div>
            <div className="text-[10px] text-zinc-600 uppercase tracking-widest font-mono">
              Team DeltaX • Google Solution Challenge 2026
            </div>
        </div>
      </div>

      {/* Right side - Forms */}
      <div className="w-full lg:w-[600px] flex items-center justify-center p-6 lg:p-12 relative overflow-y-auto">
        <div className="absolute inset-0 bg-[#0A0A0B] z-0 block lg:hidden" />
        
        <div className="w-full max-w-md relative z-10">
          
          <div className="flex lg:hidden flex-col items-center mb-8 text-center">
             <div className="w-12 h-12 bg-blue-600 rounded flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)] mb-4">
               <ShieldAlert className="w-6 h-6 text-white" />
             </div>
             <h1 className="text-xl font-bold tracking-tight text-white uppercase">SRAS</h1>
             <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Smart Resource & Aid System</p>
          </div>

          <div className="bg-[#0F0F12] border border-white/5 rounded-2xl shadow-2xl overflow-hidden relative mb-8">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-50" />
            
            <div className="flex border-b border-white/5 bg-zinc-900/30">
              <button 
                onClick={() => setActiveTab('volunteer')}
                className={`flex-1 py-4 text-[9px] uppercase tracking-widest font-bold transition-all ${activeTab === 'volunteer' ? 'text-blue-400 border-b-2 border-blue-500 bg-white/5' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                Volunteer
              </button>
              <button 
                onClick={() => setActiveTab('victim')}
                className={`flex-1 py-4 text-[9px] uppercase tracking-widest font-bold transition-all ${activeTab === 'victim' ? 'text-red-500 border-b-2 border-red-500 bg-white/5' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                Report Emergency
              </button>
              <button 
                onClick={() => setActiveTab('admin')}
                className={`flex-1 py-4 text-[9px] uppercase tracking-widest font-bold transition-all ${activeTab === 'admin' ? 'text-zinc-300 border-b-2 border-white bg-white/5' : 'text-zinc-500 hover:text-zinc-300'}`}
              >
                NGO Admin
              </button>
            </div>

            <div className="p-6 sm:p-8">
              <AnimatePresence mode="wait">
                {activeTab === 'volunteer' && (
                  <motion.form 
                    key="volunteer"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    onSubmit={handleVolunteerLogin}
                    className="space-y-4"
                  >
                    <div className="text-center mb-6">
                      <h3 className="text-lg font-bold text-white mb-2">Join Relief Mission</h3>
                      <p className="text-xs text-zinc-400">Register your current location and skills to be dispatched.</p>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Full Name</label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                          <input required type="text" value={volunteerData.name} onChange={e => setVolunteerData({...volunteerData, name: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none transition-all" placeholder="Amit Verma" />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Phone</label>
                          <div className="relative">
                            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                            <input required type="tel" value={volunteerData.phone} onChange={e => setVolunteerData({...volunteerData, phone: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none transition-all" placeholder="+91" />
                          </div>
                        </div>
                        <div>
                          <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Skill Tag</label>
                          <div className="relative">
                            <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                            <select value={volunteerData.skill} onChange={e => setVolunteerData({...volunteerData, skill: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none transition-all appearance-none">
                              {skills.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Deployment Location</label>
                        <div className="flex gap-2">
                           <div className="relative flex-1">
                             <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                             <input required type="text" value={volunteerData.location} onChange={e => setVolunteerData({...volunteerData, location: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none transition-all" placeholder="Delhi, India or GPS" />
                           </div>
                           <button type="button" onClick={detectLocation} className="p-2.5 bg-zinc-900 border border-white/10 rounded-lg hover:bg-zinc-800 transition-colors">
                              {isDetecting ? <Loader2 className="w-4 h-4 animate-spin text-blue-400" /> : <MapPin className="w-4 h-4 text-blue-400" />}
                           </button>
                        </div>
                      </div>
                    </div>

                    <button type="submit" className="w-full mt-6 bg-blue-600 hover:bg-blue-500 text-white font-bold uppercase tracking-widest text-xs py-3 rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-900/20">
                       JOIN MISSION <ChevronRight className="w-4 h-4" />
                    </button>
                  </motion.form>
                )}

                {activeTab === 'victim' && (
                  <motion.form 
                    key="victim"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    onSubmit={handleVictimSOS}
                    className="space-y-4"
                  >
                    <div className="text-center mb-6">
                      <div className="w-12 h-12 bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-3">
                         <ShieldAlert className="w-6 h-6 text-red-500 animate-pulse" />
                      </div>
                      <h3 className="text-lg font-bold text-white mb-2">Emergency Intake</h3>
                      <p className="text-xs text-zinc-400">Request immediate aid. AI will prioritize based on severity.</p>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Name (Optional)</label>
                          <input type="text" value={victimData.name} onChange={e => setVictimData({...victimData, name: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:border-red-500 focus:outline-none" placeholder="Anonymous" />
                        </div>
                        <div>
                          <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Alert Type</label>
                          <select value={victimData.emergencyType} onChange={e => setVictimData({...victimData, emergencyType: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:border-red-500 focus:outline-none appearance-none">
                            {emergencies.map(e => <option key={e} value={e}>{e}</option>)}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Describe the Situation</label>
                        <textarea required value={victimData.description} onChange={e => setVictimData({...victimData, description: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:border-red-500 focus:outline-none h-20 resize-none" placeholder="What is happening? Any trapped people?" />
                      </div>

                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Crisis Location</label>
                        <div className="flex gap-2">
                           <div className="relative flex-1">
                             <Navigation className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600" />
                             <input required type="text" value={victimData.location} onChange={e => setVictimData({...victimData, location: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white focus:border-red-500 focus:outline-none transition-all" placeholder="Detect Location" />
                           </div>
                           <button type="button" onClick={detectLocation} className="p-2.5 bg-zinc-900 border border-white/10 rounded-lg hover:bg-zinc-800 transition-colors">
                              {isDetecting ? <Loader2 className="w-4 h-4 animate-spin text-red-500" /> : <MapPin className="w-4 h-4 text-red-500" />}
                           </button>
                        </div>
                      </div>
                    </div>

                    <button type="submit" className="w-full mt-6 bg-red-600 hover:bg-red-500 text-white font-bold uppercase tracking-widest text-xs py-3 rounded-lg transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(220,38,38,0.2)]">
                       SEND SOS NOW <ShieldAlert className="w-4 h-4" />
                    </button>
                  </motion.form>
                )}

                {activeTab === 'admin' && (
                  <motion.form 
                    key="admin"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    onSubmit={handleAdminLogin}
                    className="space-y-6 py-4"
                  >
                    <div className="text-center">
                      <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Lock className="w-8 h-8 text-zinc-400" />
                      </div>
                      <h3 className="text-xl font-bold text-white mb-2">NGO Administrator</h3>
                      <p className="text-sm text-zinc-400">Secure access for SRAS mission command center.</p>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Email</label>
                        <input required type="email" value={adminData.email} onChange={e => setAdminData({...adminData, email: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none" placeholder="admin@aidconnect.in" />
                      </div>
                      <div>
                        <label className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold mb-1 block">Password</label>
                        <input required type="password" value={adminData.password} onChange={e => setAdminData({...adminData, password: e.target.value})} className="w-full bg-[#0A0A0B] border border-white/10 rounded-lg px-4 py-2.5 text-sm text-white focus:border-blue-500 focus:outline-none" placeholder="••••••••" />
                      </div>
                      <button type="submit" className="w-full bg-white hover:bg-zinc-200 text-black font-bold uppercase tracking-widest text-xs py-3 rounded-lg transition-colors flex items-center justify-center gap-2">
                        AUTHENTICATE <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
            
            <div className="bg-[#0A0A0B] p-4 text-center border-t border-white/5">
              <span className="text-[9px] text-zinc-500 uppercase tracking-widest flex items-center justify-center gap-2">
                <ShieldCheck className="w-3 h-3 text-emerald-500" /> Firebase Secured + GCP Compliant
              </span>
            </div>
          </div>
          
          <div className="flex justify-center gap-4 text-[9px] text-zinc-600 uppercase tracking-widest font-bold">
             <span>Terms</span>
             <span>•</span>
             <span>Privacy</span>
             <span>•</span>
             <span>Google Solution Challenge</span>
          </div>
        </div>
      </div>
    </div>
  );
}
