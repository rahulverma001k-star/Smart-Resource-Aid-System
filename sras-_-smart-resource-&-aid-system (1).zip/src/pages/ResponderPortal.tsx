import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Share2, Map, Shield, Users, Maximize2, AlertTriangle, FileText, ChevronRight, Check, Heart, Waves, Info, Package, Loader2 } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';

const beneficiaryStatus = [
  { name: 'Safe / Evacuated', value: 1250, color: '#10b981' },
  { name: 'In Transit', value: 340, color: '#3b82f6' },
  { name: 'Unknown / Trapped', value: 45, color: '#ef4444' }
];

export default function ResponderPortal() {
  const { logout, user } = useAuth();
  const [arMode, setArMode] = useState(false);
  const [activeZone, setActiveZone] = useState('Sector A');
  const [pdfGenerating, setPdfGenerating] = useState(false);
  const [pdfGenerated, setPdfGenerated] = useState(false);

  const handleGeneratePdf = () => {
    setPdfGenerating(true);
    setTimeout(() => {
      setPdfGenerating(false);
      setPdfGenerated(true);
      setTimeout(() => setPdfGenerated(false), 3000);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#E2E8F0] font-sans p-4 lg:p-8 flex flex-col items-center border-x border-white/5 max-w-7xl mx-auto">
      <div className="w-full flex flex-col gap-6">
        
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between pb-4 border-b border-white/10 gap-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center border-2 border-[#0A0A0B] shadow-[0_0_15px_rgba(37,99,235,0.4)]">
              <Shield className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-white uppercase">Volunteer <span className="font-light text-blue-400">Mission</span></h1>
              <p className="text-[10px] text-zinc-500 tracking-widest uppercase flex items-center gap-2 mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]"></span>
                SRAS Live Intel • AidConnect India
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => alert(`Mission coordinates shared to local mesh: ${user?.location}`)} className="px-4 py-2 border border-white/5 bg-[#0F0F12] rounded text-xs font-bold uppercase tracking-wider hover:bg-zinc-900 transition flex items-center gap-2 text-zinc-300">
              <Share2 className="w-4 h-4 text-zinc-500" /> Share Intel
            </button>
            <button 
              onClick={() => setArMode(!arMode)}
              className={`px-4 py-2 border rounded text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 ${
                arMode ? 'border-amber-500/50 bg-amber-500/20 text-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.2)]' : 'border-blue-500/30 bg-blue-600/10 hover:bg-blue-600/20 text-blue-400'
              }`}>
              <Maximize2 className="w-4 h-4" /> {arMode ? 'AR ACTIVE' : 'AR Mode (Beta)'}
            </button>
            <button onClick={logout} className="px-4 py-2 text-xs font-bold text-zinc-500 hover:text-white transition uppercase tracking-wider bg-zinc-900 border border-white/5 rounded">Exit</button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column: Stats & Information */}
          <div className="space-y-6">
            <div className="bg-[#0F0F12] border border-white/5 p-6 rounded-2xl relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-1 h-full bg-red-600" />
              <h2 className="text-[11px] font-bold text-zinc-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-500" /> Mission Briefing
              </h2>
              <div className="space-y-4">
                <div className="bg-red-950/20 border border-red-500/30 p-4 rounded-xl">
                  <div className="text-[10px] text-red-500 font-bold mb-1 uppercase tracking-wider">Priority Incident</div>
                  <div className="text-white font-bold text-sm uppercase">FLOOD LEVEL CRITICAL</div>
                  <div className="text-xs text-zinc-400 mt-2 leading-relaxed">Yamuna Bank Sector 4. Water levels rising 2cm/hr. 12 beneficiaries trapped on roof. Medical team required for infant on site.</div>
                </div>
                <div className="flex flex-col gap-1 p-4 bg-zinc-900/50 rounded-xl border border-white/5">
                  <span className="text-[10px] text-blue-400 uppercase font-bold flex items-center gap-2"><Waves className="w-3 h-3" /> Hydro Telemetry</span>
                  <span className="text-xs text-zinc-300">Dam release scheduled for 18:00 IST. Evacuation window closing.</span>
                </div>
              </div>
            </div>

            <div className="bg-[#0F0F12] border border-white/5 p-6 rounded-2xl shadow-xl">
              <h2 className="text-[11px] font-bold text-zinc-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-500" /> Beneficiary Status
              </h2>
              <div className="h-48 relative">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={beneficiaryStatus}
                      cx="50%"
                      cy="50%"
                      innerRadius={65}
                      outerRadius={85}
                      paddingAngle={5}
                      dataKey="value"
                      stroke="none"
                    >
                      {beneficiaryStatus.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#0F0F12', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '12px' }}
                      itemStyle={{ color: '#fff', fontSize: '12px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-white">1,635</div>
                    <div className="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">Total Assisted</div>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-2 mt-6">
                {beneficiaryStatus.map(s => (
                  <div key={s.name} className="flex items-center justify-between p-3 bg-zinc-900/50 rounded-xl border border-white/5">
                    <div className="flex items-center gap-2">
                       <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />
                       <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">{s.name}</span>
                    </div>
                    <span className="text-xs font-bold text-white">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column (Span 2): Map & Schematics */}
          <div className="lg:col-span-2 bg-[#0F0F12] rounded-2xl flex flex-col overflow-hidden border border-white/5 min-h-[600px] shadow-2xl">
            <div className="p-4 bg-zinc-900/30 border-b border-white/5 flex justify-between items-center z-10 shrink-0 backdrop-blur-md">
              <h2 className="text-[11px] font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                <Map className="w-4 h-4 text-orange-500" /> Sector Grid Schematic
              </h2>
              <div className="flex gap-2 bg-[#0A0A0B] p-1 border border-white/10 rounded-lg">
                {['Sector A', 'Sector B', 'Sector C'].map(zone => (
                  <button 
                    key={zone}
                    onClick={() => setActiveZone(zone)} 
                    className={`px-4 py-1.5 text-[9px] font-bold uppercase rounded-md transition-all ${activeZone === zone ? 'bg-blue-600 text-white shadow-lg' : 'bg-transparent text-zinc-500 hover:text-zinc-300'}`}
                  >
                    {zone}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex-1 relative bg-[#050506] flex items-center justify-center p-8">
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:32px_32px]"></div>
              
              <div className="absolute top-6 flex justify-center z-20 pointer-events-none w-full px-6">
                 <div className="bg-black/60 backdrop-blur-xl px-6 py-2.5 rounded-full border border-white/10 flex gap-8 text-[9px] font-bold text-zinc-400 uppercase tracking-widest shadow-2xl overflow-x-auto whitespace-nowrap">
                   <span className="flex items-center gap-2"><div className="w-2.5 h-2.5 bg-red-500 rounded-full shadow-[0_0_10px_rgba(239,68,68,0.5)]" /> Inactive Zone</span>
                   <span className="flex items-center gap-2"><div className="w-2.5 h-2.5 bg-green-500 rounded-full shadow-[0_0_10px_rgba(34,197,94,0.5)]" /> Aid Station</span>
                   <span className="flex items-center gap-2"><div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(59,130,246,0.5)]" /> Supply Drop</span>
                 </div>
              </div>
              
              <div className="w-full max-w-3xl aspect-video border-2 border-zinc-800 rounded-2xl relative bg-[#0F0F12]/50 overflow-hidden shadow-[0_0_100px_rgba(0,0,0,0.5)]">
                 {/* Relief Camp Layout Visualization */}
                 <div className="absolute inset-x-0 bottom-0 h-1/4 bg-blue-900/10 border-t border-blue-500/10 flex items-center justify-center font-black text-4xl text-blue-500/10 tracking-[1em]">YAMUNA RIVER</div>
                 
                 <div className="absolute top-20 left-20 right-20 bottom-32 grid grid-cols-4 grid-rows-3 gap-2">
                    {Array.from({length: 12}).map((_, i) => (
                      <div key={i} className="border border-white/5 bg-zinc-900/30 rounded flex items-center justify-center text-[10px] text-zinc-700 font-mono">GRID-{i+10}</div>
                    ))}
                 </div>

                 {/* Incident Location */}
                 {activeZone === 'Sector A' && (
                    <div className="absolute top-1/4 left-1/3 flex flex-col items-center">
                       <div className="w-16 h-16 bg-red-600/20 rounded-full animate-ping absolute" />
                       <div className="w-16 h-16 bg-red-600/30 rounded-full animate-pulse border border-red-500 flex items-center justify-center backdrop-blur-sm shadow-[0_0_30px_rgba(220,38,38,0.4)]">
                          <AlertTriangle className="w-7 h-7 text-red-500" />
                       </div>
                       <span className="text-[8px] font-bold bg-black px-2 py-0.5 rounded border border-red-500/50 mt-2 text-red-400">CRITICAL NEED</span>
                    </div>
                 )}

                 <div className="absolute bottom-40 right-20 flex flex-col items-center">
                    <div className="w-12 h-12 bg-blue-600/20 rounded-full border border-blue-500/30 flex items-center justify-center backdrop-blur-sm animate-bounce">
                       <Package className="w-5 h-5 text-blue-400" />
                    </div>
                    <span className="text-[8px] font-bold bg-black px-2 py-0.5 rounded border border-blue-500/50 mt-2 text-blue-400">SUPPLY DROP</span>
                 </div>
              </div>
            </div>
            
            <div className="p-6 bg-zinc-900/50 border-t border-white/5 shrink-0 backdrop-blur-md">
              <div className="flex gap-4">
                <button 
                  onClick={handleGeneratePdf}
                  disabled={pdfGenerating || pdfGenerated}
                  className={`flex-1 py-3.5 text-[11px] font-bold uppercase tracking-widest rounded-xl flex items-center justify-center gap-3 transition-all shadow-xl active:scale-95 ${
                    pdfGenerated ? 'bg-emerald-600 text-white' : 
                    pdfGenerating ? 'bg-zinc-800 text-zinc-500 border border-white/5' : 
                    'bg-white text-black hover:bg-zinc-200'
                  }`}>
                  {pdfGenerated ? <><Check className="w-5 h-5" /> FIELD REPORT SENT</> : 
                   pdfGenerating ? <><Loader2 className="w-5 h-5 animate-spin" /> SYNCHRONIZING...</> :
                   <><FileText className="w-5 h-5" /> SYNC FIELD REPORT (Offline Safe)</>}
                </button>
                <button className="px-6 py-3.5 bg-zinc-800 border border-white/10 rounded-xl text-zinc-400 hover:text-white transition-colors">
                   <Info className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

