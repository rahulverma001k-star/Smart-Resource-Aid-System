import React, { createContext, useContext, useState, useEffect } from 'react';

type Role = 'victim' | 'volunteer' | 'admin' | null;

interface AuthContextType {
  role: Role;
  login: (role: Role, userData?: any) => void;
  logout: () => void;
  user: any;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [role, setRole] = useState<Role>(() => {
    return (localStorage.getItem('sras_role') as Role) || null;
  });

  const [user, setUser] = useState<any>(() => {
    const saved = localStorage.getItem('sras_user');
    return saved ? JSON.parse(saved) : null;
  });

  const login = (newRole: Role, userData?: any) => {
    setRole(newRole);
    
    // Merge provided user data or fallback to defaults
    const newUserData = userData || {
      name: newRole === 'victim' ? 'Victim/Beneficiary' : newRole === 'volunteer' ? 'Volunteer' : 'NGO Administrator',
      id: Math.random().toString(36).substring(7),
      role: newRole
    };
    newUserData.role = newRole; // Enforce role
    
    setUser(newUserData);
    localStorage.setItem('sras_role', newRole as string);
    localStorage.setItem('sras_user', JSON.stringify(newUserData));
  };

  const logout = () => {
    setRole(null);
    setUser(null);
    localStorage.removeItem('sras_role');
    localStorage.removeItem('sras_user');
  };

  return (
    <AuthContext.Provider value={{ role, login, logout, user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
