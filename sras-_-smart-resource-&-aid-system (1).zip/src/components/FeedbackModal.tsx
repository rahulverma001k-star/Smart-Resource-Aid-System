import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X } from 'lucide-react';

export default function FeedbackModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedback.trim()) return;
    setSubmitted(true);
    setTimeout(() => {
      setIsOpen(false);
      setSubmitted(false);
      setFeedback('');
    }, 2000);
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 p-3 bg-[#0F0F12] border border-white/10 text-zinc-400 rounded-full shadow-lg hover:text-white hover:border-white/20 transition z-50 flex items-center justify-center backdrop-blur-md"
        title="Provide Feedback"
      >
        <MessageSquare className="w-5 h-5" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-sans"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0F0F12] border border-white/10 rounded-2xl p-6 w-full max-w-md shadow-2xl relative"
            >
              <button 
                onClick={() => setIsOpen(false)}
                className="absolute top-4 right-4 text-zinc-500 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
              
              <h3 className="text-[11px] font-bold text-zinc-400 uppercase tracking-widest mb-6">Prototype Feedback</h3>
              
              {submitted ? (
                <div className="py-8 text-center text-[10px] uppercase tracking-widest font-bold text-green-500 border border-green-500/20 bg-green-500/10 rounded-lg">
                  Report Recorded in DB
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <p className="text-xs text-zinc-500 mb-6 font-mono">
                    Reporting issues helps us improve the AEGIS platform before production deployment.
                  </p>
                  <textarea
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    placeholder="Describe any issues or suggestions..."
                    className="w-full h-32 bg-[#050506] border border-white/5 rounded-lg p-4 text-white placeholder-zinc-600 focus:outline-none focus:border-white/20 mb-4 resize-none text-[13px]"
                  />
                  <button 
                    type="submit"
                    className="w-full py-3 bg-white text-black font-bold uppercase tracking-widest text-[11px] rounded-lg hover:bg-zinc-200 transition"
                  >
                    Submit Report
                  </button>
                </form>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
