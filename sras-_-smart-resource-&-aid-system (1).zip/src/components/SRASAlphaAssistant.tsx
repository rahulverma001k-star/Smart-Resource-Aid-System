import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { Bot, X, Send, Command, Loader2 } from 'lucide-react';

let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({ apiKey });
  }
} catch (e) {
  console.warn("Failed to initialize GoogleGenAI. Did you forget to set GEMINI_API_KEY?", e);
}

const createIncidentDeclaration = {
  name: "createIncident",
  description: "Create a new crisis incident entry in the Aegis system based on user report.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      type: { type: Type.STRING, description: "Type of incident (e.g., MEDICAL, FIRE, SECURITY, IoT ALERT, GENERAL EVACUATION)" },
      location: { type: Type.STRING, description: "Location of the incident (e.g., Pool Deck, Lobby, Level 4)" },
      severity: { type: Type.STRING, description: "Severity of the incident ('high', 'medium', 'low')" }
    },
    required: ["type", "location", "severity"]
  }
};

const resolveIncidentDeclaration = {
  name: "resolveIncident",
  description: "Mark an active or investigating incident as RESOLVED.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      incidentId: { type: Type.STRING, description: "The ID of the incident to resolve, e.g., 'INC-2041'" }
    },
    required: ["incidentId"]
  }
};

const saveInformationDeclaration = {
  name: "saveInformation",
  description: "Save a log, note, or piece of information for future reference in the local system database.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      note: { type: Type.STRING, description: "The information, notes, or data to log." }
    },
    required: ["note"]
  }
};

const assignResponderDeclaration = {
  name: "assignResponder",
  description: "Assign a specific team or responder to an active incident.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      incidentId: { type: Type.STRING, description: "The ID of the incident, e.g., 'INC-2041'" },
      team: { type: Type.STRING, description: "The responder team to assign (e.g., 'Alpha Team', 'Medical Unit', 'Security Squad')" }
    },
    required: ["incidentId", "team"]
  }
};

export default function SRASAlphaAssistant({ incidents, setIncidents, user }) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState(() => {
    const saved = localStorage.getItem('sras_alpha_messages');
    return saved ? JSON.parse(saved) : [{ role: 'model', text: `Hello ${user?.name || 'Relief Manager'}, I am SRAS Alpha. How can I assist you with mission coordination, incident triage, or logging intelligence?` }];
  });
  const [savedInformation, setSavedInformation] = useState(() => {
    const saved = localStorage.getItem('sras_ai_logs');
    return saved ? JSON.parse(saved) : [];
  });
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  
  // Save messages to local storage
  useEffect(() => {
    localStorage.setItem('sras_alpha_messages', JSON.stringify(messages));
  }, [messages]);

  // Save logs to local storage
  useEffect(() => {
    localStorage.setItem('sras_ai_logs', JSON.stringify(savedInformation));
  }, [savedInformation]);

  // Chat context ref
  const chatRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  useEffect(() => {
    if (ai) {
      chatRef.current = ai.chats.create({
        model: "gemini-2.5-flash",
        history: messages.map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        })),
        config: {
          systemInstruction: `You are SRAS Alpha, the core intelligence for the Smart Resource & Aid System. 
Your job is to assist the NGO relief manager. You can resolve crisis incidents, log/save mission intelligence, assign volunteer teams, and provide emergency response strategies.
Keep your answers professional, concise, and mission-focused.

CURRENT CRISIS INCIDENTS:
${JSON.stringify(incidents)}

MISSION INTEL LOGS:
${JSON.stringify(savedInformation)}`,
          tools: [{ functionDeclarations: [createIncidentDeclaration, resolveIncidentDeclaration, saveInformationDeclaration, assignResponderDeclaration] }]
        }
      });
    }
  }, [incidents, savedInformation]); 

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;
    
    const userMsg = input.trim();
    setInput('');
    
    const newMessages = [...messages, { role: 'user', text: userMsg }];
    setMessages(newMessages);
    setIsTyping(true);

    try {
      if (!ai || !chatRef.current) {
        setTimeout(() => {
          setMessages(prev => [...prev, { role: 'model', text: "SYSTEM ERROR: SRAS Cloud API Key missing or GoogleGenAI failed to initialize." }]);
          setIsTyping(false);
        }, 1000);
        return;
      }
      
      let response = await chatRef.current.sendMessage({ message: userMsg });

      if (response.functionCalls && response.functionCalls.length > 0) {
        for (const call of response.functionCalls) {
          let functionReply = "";
          
          if (call.name === 'createIncident') {
            const { type, location, severity } = call.args;
            const newId = `INC-${Math.floor(Math.random() * 10000)}`;
            const newIncident = {
              id: newId,
              type,
              status: 'ACTIVE',
              location,
              time: 'Just now',
              severity,
              x: 50,
              y: 50
            };
            setIncidents(prev => [newIncident, ...prev]);
            functionReply = `SRAS Intel: Created mission entry ${newId} (${type}) at ${location} with ${severity} priority.`;
          } 
          else if (call.name === 'resolveIncident') {
            const { incidentId } = call.args;
            setIncidents(prev => prev.map(inc => inc.id === incidentId ? { ...inc, status: 'RESOLVED' } : inc));
            functionReply = `SRAS Intel: Mission ${incidentId} marked as RESOLVED.`;
          }
          else if (call.name === 'saveInformation') {
            const { note } = call.args;
            setSavedInformation(prev => [...prev, { date: new Date().toISOString(), note }]);
            functionReply = `SRAS Intel: Mission intelligence successfully archived in secure cloud logs.`;
          }
          else if (call.name === 'assignResponder') {
            const { incidentId, team } = call.args;
            setIncidents(prev => prev.map(inc => inc.id === incidentId ? { ...inc, responder: team } : inc));
            functionReply = `SRAS Intel: Dispatched ${team} to Crisis Site ${incidentId}.`;
          }
          
          response = await chatRef.current.sendMessage({
             message: [{
               functionResponse: {
                 name: call.name,
                 response: { result: functionReply }
               }
             }]
          });
        }
      }

      setMessages(prev => [...prev, { role: 'model', text: response.text }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "SYSTEM ERROR: SRAS Core Link unstable. Unable to process command." }]);
    } finally {
      setIsTyping(false);
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-blue-600 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)] hover:scale-110 transition-transform border-2 border-white/10 group z-50">
        <Bot className="w-6 h-6 text-white group-hover:animate-bounce" />
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
        </span>
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 w-96 h-[500px] bg-[#0A0A0B] border border-blue-500/30 rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50">
      {/* Header */}
      <div className="h-14 bg-[#0F0F12] border-b border-white/5 flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-blue-600/20 border border-blue-500/50 flex items-center justify-center">
            <Command className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">SRAS Alpha Intel</div>
            <div className="text-[9px] text-green-400 uppercase tracking-widest">Core Active</div>
          </div>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-zinc-500 hover:text-white transition-colors">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 bg-black/40 overflow-y-auto p-4 flex flex-col gap-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-xl text-sm ${msg.role === 'user' ? 'bg-blue-600 text-white rounded-br-sm' : 'bg-zinc-800 text-zinc-300 border border-white/5 rounded-bl-sm'}`}>
              <span className="text-[9px] uppercase tracking-widest font-bold opacity-50 block mb-1">
                {msg.role === 'user' ? 'Relief Manager' : 'SRAS Alpha'}
              </span>
              <p className="leading-relaxed">{msg.text}</p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="max-w-[80%] p-3 rounded-xl bg-zinc-800 text-zinc-300 border border-white/5 rounded-bl-sm flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-blue-400" /> <span className="text-xs">Processing mission data...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 bg-[#0F0F12] border-t border-white/5 flex gap-2">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Issue mission command..."
          className="flex-1 bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
        />
        <button 
          onClick={handleSend}
          disabled={isTyping || !input.trim()}
          className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center hover:bg-blue-500 disabled:opacity-50 disabled:hover:bg-blue-600 transition-colors">
          <Send className="w-4 h-4 text-white" />
        </button>
      </div>
    </div>
  );
}
