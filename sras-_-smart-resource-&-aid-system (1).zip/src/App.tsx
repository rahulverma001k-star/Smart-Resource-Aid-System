/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './pages/Login';
import GuestApp from './pages/GuestApp';
import StaffDashboard from './pages/StaffDashboard';
import ResponderPortal from './pages/ResponderPortal';
import FeedbackModal from './components/FeedbackModal';

function AppContent() {
  const { role } = useAuth();
  
  const renderApp = () => {
    if (!role) {
      return <Login />;
    }

    if (role === 'victim') {
      return <GuestApp />; // Will rename/refactor this to VictimPortal/GuestApp
    }

    if (role === 'admin') {
      return <StaffDashboard />; // Admin Dashboard
    }

    if (role === 'volunteer') {
      return <ResponderPortal />; // Volunteer Interface
    }

    return <div>Unknown Role</div>;
  };

  return (
    <>
      {renderApp()}
      {role && <FeedbackModal />}
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
